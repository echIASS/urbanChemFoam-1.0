LASTTIME=86400
UNIFORM=uniform
rm -rf ${LASTTIME}
reconstructPar -time ${LASTTIME}
LASTSTEP=`ls -d ${LASTTIME}* | head -n1`
if [ "${LASTSTEP}" != "${LASTTIME}" ]; then
	mv ${LASTSTEP} ${LASTTIME}
	LASTSTEP=${LASTTIME}
fi
mv ${LASTSTEP}/uniform .
